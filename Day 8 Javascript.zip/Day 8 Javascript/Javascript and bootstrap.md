* Introduction to
* JavaScript
* Getting Started
* JavaScript
* Fundamentals
* Framework and
* libraries
* Variables ( var ,
* let, const )
* JavaScript Arrays
* &nbsp;map,
* JavaScript Function
* Function Declaration
* Arrow Functions
* Callbacks

Array Methods

forEach, filter, reduce



Asynchronous JavaScript

Synchronous vs Asynchronous

Call Stack

Event loop

Callback Queue

JSON

JSON.parse()

Bootstrap 5

Introduction to

Bootstrap 5

Bootstrap Setup

(CDN)

Layout and Grid

System

Container, Row,

Column

Bootstrap Utilities

and Helpers

Responsive

Design with Bootstrap

Customization

and Extensions

jQuery

What is jQuery ?

jQuery Selectors

Data Types

JavaScript

Operators

Control Flow

if - else,

switch,Loops

JavaScript Objects

Object Creation,

Properties, Methods

this Keyword

Closures

IIFE

DOM (Document

Object Model)

Selecting Elements

Modifying

Content

DOM

Manipulation

Traversing the

DOM

Events and Event

Listeners

JSON.stringify()

Callbacks

Callback

Functions

Callback hell

Promises,

async/await

Fetch API

ES6 features

Debugging and

Testing JavaScript

Responsive

Breakpoints

Essential

Components

Typography,

Buttons, Cards, Forms

Navbar, Modals,

Dropdowns

DOM

manipulation \& events

jQuery Effects

Basic AJAX with

jQuery

